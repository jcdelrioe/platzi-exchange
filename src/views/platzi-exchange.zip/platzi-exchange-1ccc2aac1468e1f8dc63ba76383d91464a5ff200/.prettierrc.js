module.exports = {
  tabWidth: 2,
  semi: false,
  singleQuote: true
}
